sed -i 's/Results502/Results276/g' fourNQG.cc
sed -i 's/Results502/Results276/g' fourAsym.cc
sed -i 's/Results502/Results276/g' fourRAA.cc
sed -i 's/Results502/Results276/g' fourFF.cc
sed -i 's/Results502/Results276/g' fourRap.cc
sed -i 's/Results502/Results276/g' fourLambda.cc
sed -i 's/Results502/Results276/g' fourDijet.cc
sed -i 's/Results502/Results276/g' fourShapes.cc

./fourAsym.sh

./fourRAA.sh

./fourFF.sh

./fourLambda.sh

./fourRap.sh

./fourShapes.sh

#./fourFFc.sh

g++ fourNQG.cc -o fourNQG
./fourNQG

sed -i 's/Strong/Rad/g' fourNQG.cc

g++ fourNQG.cc -o fourNQG
./fourNQG

sed -i 's/Rad/Coll/g' fourNQG.cc

g++ fourNQG.cc -o fourNQG
./fourNQG

sed -i 's/Coll/Strong/g' fourNQG.cc

g++ fourDijet.cc -o fourDijet
./fourDijet

sed -i 's/Strong/Rad/g' fourDijet.cc

g++ fourDijet.cc -o fourDijet
./fourDijet

sed -i 's/Rad/Coll/g' fourDijet.cc

g++ fourDijet.cc -o fourDijet
./fourDijet

sed -i 's/Coll/Strong/g' fourDijet.cc
